<!DOCTYPE html>
<html> 
<head> 
<style>
.chess
{
position:absolute;
top: 100px;
left:550px;
}
body
{
background-image: url("ch.jpg");
background-repeat: no-repeat;
background-size: cover;
}
</style>
<title>Assignment 4</title>
</head>
<body> 
<div class="chess">

<h1 style="text-align:center;">ASSIGNMENT 4</h1>
<h3 style="text-align:center;">CHESS BOARD IN PHP</h3>
<table width="400px" >
<?php
for($hor=1;$hor<=8;$hor++)
{
echo "<tr>";
for($ver=1;$ver<=8;$ver++)
{
$s=$hor+$ver;
if($s%2==0)
{
echo "<td height=30px width=30px  bgcolor=black></td>";
}
else
{
echo "<td height=30px width=30px  bgcolor=white></td>";
}
}
echo "</tr>";
}
?>
</div>
</table>
</body>
</html>