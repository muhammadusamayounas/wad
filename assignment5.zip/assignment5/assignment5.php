<!DOCTYPE html>
<html> 
<head> 
<style>
body
{
background-image: url("a.jpeg");
background-repeat: no-repeat;
background-size:cover;
}
h1 {
  color:white;
}
h3{
  color:white;
}
.sort
{
color:white;
text-align: center;
font-size: 200%;
}
</style>
<title>Assignment 5</title>
</head>
<body> 
<h1 style="text-align:center;">ASSIGNMENT 5</h1>
<h3 style="text-align:center;">PHP PROGRAM TO SORT A LIST OF ELEMENT USING MERGE SORT</h3>
<div class="sort">
<?php
function merge($a, $b)
{
$x = array();
while (count($a) > 0 && count($b) > 0)
{
if($a[0] > $b[0])		
{
$x[] = $b[0];
$b = array_slice($b , 1);
}
else
{
$x[] = $a[0];
$a = array_slice($a, 1);
}
}
while (count($a) > 0){
$x[] = $a[0];
$a = array_slice($a, 1);
}
while (count($b) > 0){
$x[] = $b[0];
$b = array_slice($b, 1);
}
return $x;
}
function sorting($arr)
{
if(count($arr) == 1 ) 
return $arr;
$c = count($arr) / 2;
$a = array_slice($arr, 0, $c);
$b = array_slice($arr, $c);
$a = sorting($a);
$b = sorting($b);
return merge($a, $b);
}
$givenarray = array(3,5,6,7,8,33,1,4,12,21,34,11,54,56,97,23,90,222,234,111);
echo "<br>"."THE GIVEN ARRAY";
echo "<br>".implode(', ',$givenarray )."<br>";
echo "<br>"."\nARRAY AFTER MERGE SORT ";
echo "<br>".implode(', ',sorting($givenarray))."<br>";
?>
</div>
</body>
</html>