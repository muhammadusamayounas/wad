<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
</head>
<body>

<div class="container">
  <nav class="navbar navbar-default">
  <div class="container-fluid">
    <div class="navbar-header">
      <a class="navbar-brand" href="#">PHP Form Validation </a>
    </div>
    <ul class="nav navbar-nav">
      <li class="active"><a href="http://localhost/wad/php-forms/index.php">Home</a></li>
      <li><a href="http://localhost/wad/php-forms/pages/new-page.php">New Page</a></li>
      <li><a href="http://localhost/wad/php-forms/session-destroy.php">Destroy Session</a></li>
    </ul>
  </div>
  </nav>