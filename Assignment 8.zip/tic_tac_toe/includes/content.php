<?php

if (! isset($_SESSION["p1"]) && ! isset($_SESSION["p2"])) {
	$_SESSION["p1"] = [];
	$_SESSION["p2"] = [];
}

//Add logic here
if (isset($_POST["p1"])) {
	//$_SESSION["p1"]
	$_SESSION["p1"] = (array) null;
}

if (isset($_POST["p2"])) {
	//$_SESSION["p2"]
	$_SESSION["p2"] = (array) null;
}

if (isset($_POST["reset"])) {
	$_SESSION["p1"] = [];
	$_SESSION["p2"] = [];
	unset($_POST);
}

/*if (isset($_POST["save"])) {
	$p1 = implode(",", $_SESSION["p1"]);
	$p2 = implode(",", $_SESSION["p2"]);
	
	$sql = "INSERT INTO turns(player1, player2) VALUES('$p1' , '$p2')";
	//echo "$sql <br>";

	$conn->query($sql);
	$conn->close();
}*/

function checkHorizontal($array) {
	if ( (in_array("0 X 0", $array) && in_array("0 X 1", $array) && in_array("0 X 2", $array))
		|| (in_array("1 X 0", $array) && in_array("1 X 1", $array) && in_array("1 X 2", $array))
		|| (in_array("2 X 0", $array) && in_array("2 X 1", $array) && in_array("2 X 2", $array)) ):
		return 1;
	else:
		return 0;
	endif;
}

function checkVertical($array) {
	if ( (in_array("0 X 0", $array) && in_array("1 X 0", $array) && in_array("2 X 0", $array))
		|| (in_array("0 X 1", $array) && in_array("1 X 1", $array) && in_array("2 X 1", $array))
		|| (in_array("0 X 2", $array) && in_array("1 X 2", $array) && in_array("2 X 2", $array)) ):
		return 1;
	else:
		return 0;
	endif;
}

function checkDiagonal($array) {
	if ( (in_array("0 X 0", $array) && in_array("1 X 1", $array) && in_array("2 X 2", $array))
		|| (in_array("0 X 2", $array) && in_array("1 X 1", $array) && in_array("2 X 0", $array)) ):
		return 1;
	else:
		return 0;
	endif;
}

function checkWinner($array) {
	if (checkHorizontal($array)
		|| checkVertical($array)
		|| checkDiagonal($array)):
		return 1;
	else:
		return 0;
	endif;	
}
?>

<style type="text/css">
	.red {
		background-color: red;
	}

	.green {
		background-color: green;
	}

	.display-none {
		display: none;
	}

	input[type="submit"] {
		margin: 30px 30px;
		padding: 15px;
		width: 150px;
	}
</style>

<div class="p-3 mb-2 bg-success text-white">Player 1</div>
<div class="p-3 mb-2 bg-danger text-white">Player 2</div>
<form action="index.php" method="post">
<?php
for($row=0; $row<3; $row++):
	echo '<div class="row" id="row-'.$row.'">';
		
	for($col=0; $col<3; $col++):
		$id = $row.''.$col;
		//echo "$id";

		if (isset($_POST["$id"])) {
			if (isset($_POST["p1"])) {
				$temp = $_POST["$id"];

				if (! in_array($temp, $_SESSION["p2"])) {
					array_push($_SESSION["p1"], $temp);
				}
			} elseif (isset($_POST["p2"])) {
				$temp = $_POST["$id"];

				if (! in_array($temp, $_SESSION["p1"])) {
					array_push($_SESSION["p2"], $temp);
				}
			}
		}
		?>
		<div class="col-sm-4 tictactoecol">
			<div class="card h-100">
				<div class="card-body <?php
				//check and change the box color based on player
				$var = $row.' X '.$col;
				if (in_array($var, $_SESSION["p1"])):
					echo "green";
				elseif (in_array($var, $_SESSION["p2"])):
					echo "red";
				endif;			
				?>">
					<h2 class="card-title">
						<input type="checkbox" name="<?php echo $id; ?>" value="<?php echo $row.' X '.$col; ?>"
						<?php
							$var = $row.' X '.$col;
							if (in_array($var, $_SESSION['p1']) || in_array($var, $_SESSION['p2'])):
									echo "checked ";
									echo "class = 'display-none' ";
							endif;
						?> />

						<?php echo $row.' X '.$col; ?>
					</h2>
			  	</div>
			</div>
		</div>
	  <?php
	endfor;	
	echo '</div>';
endfor;
?>

<input type="submit" name="p1" class="btn btn-success" value="Player1" 
<?php if (isset($_POST["p1"])): ?>
	disabled
<?php endif; ?>
/>

<input type="submit" name="p2" class="btn btn-danger" value="Player2"
<?php if (isset($_POST["p2"])): ?>
	disabled
<?php endif; ?>
/>

<input type="submit" name="reset" class="btn btn-primary" value="Reset" />
<input type="submit" name="save" class="btn btn-primary" value="Save" />

<?php
	/*echo "<pre>";
	print_r($_SESSION);
	echo "</pre>";

	echo "<pre>";
	print_r($_POST);
	echo "</pre>";*/

	if (checkWinner($_SESSION["p1"])):
		echo "<script> alert('Player1 wins!');
		window.location ='includes/session_destroy.php'; </script>";

	elseif (checkWinner($_SESSION["p2"])):
		echo "<script> alert('Player2 wins!');
		window.location ='includes/session_destroy.php'; </script>";

	endif;
?>
</form>