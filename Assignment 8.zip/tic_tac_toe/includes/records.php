<?php
include "db_connection.php";

$sql = "SELECT * FROM turns";

$res = $conn->query($sql);
echo "<br><br>";

echo "<table border='1px' celspacing='2px'>";
echo "<tr>";
echo "<th>id</th>";
echo "<th>Player1</th>";
echo "<th>Player2</th>";
echo "<th>Time</th>";
echo "</tr>";
while ($row = $res->fetch_assoc()) {
	echo "<tr>";
	echo "<td>" . $row["id"] . "</td>";
	echo "<td>" . $row["player1"] . "</td>";
	echo "<td>" . $row["player2"] . "</td>";
	echo "<td>" . $row["time"] . "</td>";
?>
	<td>
		<a href="../index.php?id=<?php echo $row['id']; ?>"><button>Restore</button></a>
	</td>

<?php
	echo "</tr>";
}
echo "</table>";


$conn->close();

?>