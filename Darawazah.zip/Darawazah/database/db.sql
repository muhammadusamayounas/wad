



/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

CREATE DATABASE IF NOT EXISTS `project` DEFAULT CHARACTER SET latin1 COLLATE latin1_swedish_ci;
USE `project`;



CREATE TABLE `brands` (
  `brand_id` int(100) NOT NULL,
  `brand_title` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;



INSERT INTO `brands` (`brand_id`, `brand_title`) VALUES
(1, 'Lenovo'),
(2, 'Samsung'),
(3, 'Apple'),
(4, 'Cambridge'),
(5, 'Royle Tag'),
(6, 'Shirt and Tie Shop'),
(7, 'Bata'),
(8, 'Service'),
(9, 'Stylo'),
(10, 'Haire'),
(11, 'Pel'),
(12, 'Dalawance'),
(13, 'CA'),
(14, 'HS'),
(15, 'Gul Ahmed'),
(16, 'khaadi'),
(17, 'Oxford');



CREATE TABLE `cart` (
  `id` int(10) NOT NULL,
  `p_id` int(10) NOT NULL,
  `ip_add` varchar(250) NOT NULL,
  `user_id` int(10) NOT NULL,
  `product_title` varchar(100) NOT NULL,
  `product_image` varchar(300) NOT NULL,
  `qty` int(100) NOT NULL,
  `price` int(100) NOT NULL,
  `total_amount` int(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;



CREATE TABLE `categories` (
  `cat_id` int(11) NOT NULL,
  `cat_title` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;



INSERT INTO `categories` (`cat_id`, `cat_title`) VALUES
(1, 'Electronics'),
(2, 'Ladies Wear'),
(3, 'Mens Wear'),
(4, 'Home Appliances'),
(5, 'Sports');



CREATE TABLE `customer_order` (
  `id` int(100) NOT NULL,
  `uid` int(100) NOT NULL,
  `pid` int(100) NOT NULL,
  `p_name` varchar(255) NOT NULL,
  `p_price` int(100) NOT NULL,
  `p_qty` int(100) NOT NULL,
  `p_status` varchar(100) NOT NULL,
  `tr_id` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;







CREATE TABLE `products` (
  `product_id` int(100) NOT NULL,
  `product_cat` varchar(100) NOT NULL,
  `product_brand` varchar(100) NOT NULL,
  `product_title` varchar(50) NOT NULL,
  `product_price` int(100) NOT NULL,
  `product_desc` text NOT NULL,
  `product_image` text NOT NULL,
  `product_keywords` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;



INSERT INTO `products` (`product_id`, `product_cat`, `product_brand`, `product_title`, `product_price`, `product_desc`, `product_image`, `product_keywords`) VALUES
(1, '1', '1', 'Lenovo Yoga C740', 230000, '10th Gen Core i7 QuadCore 12GB', 'lenovo1.jpg', 'Lenovo'),
(2, '1', '1', 'Lenovo IdeaPad L340', 73000, '8th Gen Ci5 QuadCore 04GB 1TB HDD 15.6" HD', 'lenovo2.jpg', 'Lenovo'),
(3, '1', '1', 'Lenovo Ideapad 330s', 545000, '8th Gen Ci3 04GB RAM 128GB SSD 15.6" HD LED Windows 10 (Midnight Blue)', 'lenovo3.jpg', 'Lenovo'),

(4, '1', '2', 'Samsung Galaxy S10 Plus 512GB', 219000, 'Samsung has showed its powerful Galaxy S10 but yet bigger version with Plus 512GB ROM', 'sm1.jpg', 'Samsung'),
(5, '1', '2', 'Samsung Galaxy Note 9 512GB', 170000, 'Samsung has launched its powerful Galaxy Note 9 but yet bigger version with 512GB ROM', 'sm2.jpg', 'Samsung'),
(6, '1', '2', 'Samsung Galaxy A80', 114999, 'Samsung Galaxy A80 - A Flagship With Rotating Camera!', 'sm3.jpg', 'Samsung'),

(7, '1', '3', 'Apple iPhone 11 Pro Max', 235000, 'Apple looks keen to bring iPhone 11 that is the high-end Pro Max version of the series along with its two other variants. These upcoming trio series of the company will go official on 10th of the September', 'ip1.jpg', 'Apple'),
(8, '1', '3', 'Apple iPhone 11', 164000, 'Apple is developing and now iPhone 11 got leaked in the wild showing the outline of its new and innovative design.', 'ip2.jpg', 'Apple'),
(9, '1', '3', 'Apple iPhone 11 Pro', 545000, 'Apple is going to launch iPhone 11 and it will be the Pro version of the series', 'ip3.jpg', 'Apple'),


(10, '3', '4', 'Sharp 3 Piece Slim Fit Men Suit', 26000, 'Grey checks', 'cm1.jpg', 'Cambridge'),
(11, '3', '4', 'Sharp 3 Piece Slim Fit Men Suit', 26000, 'Blue checks', 'cm2.jpg', 'Cambridge'),


(12, '3', '5', 'V-Neck F/S EVN3240-MR', 1975, '50 % off', 'rl1.jpg', 'Royal Tag'),
(13, '3', '5', 'Round Neck F/S LM1904-GR', 3153, '50 % off', 'rl2.jpg', 'Royal Tag'),


(14, '3', '6', 'Business Semi Formal Shirt', 2796, 'WHITE AND GREY CHECK BUSINESS CASUAL FULL SLEEVE BUTTON DOWN SHIRT', 'st2.jpg', 'Shirt and Tie Shop'),



(15, '3', '7', 'FORMAL SHOES', 4000, 'FORMAL SHOES', 'bt1.jpg', 'Bata'),
(16, '3', '7', 'FORMAL SHOES', 3000, 'FORMAL SHOES', 'bt2.jpg', 'Bata'),


(17, '3', '8', 'CASUAL SHOES', 4000, 'CASUAL SHOES', 'sv1.jpg', 'Service'),
(18, '3', '8', 'CASUAL SHOES', 3000, 'CASUAL SHOES', 'sv2.jpg', 'Service'),


(19, '2', '9', 'FORMAL SHOES', 4000, 'BLACK COLOR FORMAL COURT SHOES WINTER', 'sp1.jpg', 'Stylo'),
(20, '2', '9', 'FORMAL SHOES', 3000, 'BEIGE COLOR FORMAL COURT SHOES WINTER', 'sp2.jpg', 'Stylo'),



(21, '4', '10', 'Refrigerators  HRF-438TDB', 34000, '100 Hours Cooling Retention', 'h1.jpg', 'Haier'),
(22, '4', '10', ' Refrigerators  HRF-336TDC', 33000, 'One Touch Smart Control', 'h2.jpg', 'Haier'),

(23, '4', '11', 'PEL Arctic InverterOn 155 Deep Freezer', 48000, 'Capacity 410 Liters', 'pl1.jpg', 'PEL'),
(24, '4', '11', 'PEL ACE Air Conditioner 1 Ton', 55000, 'PEL Air Conditioners with its biggest indoor unit design provides cooling in large spaces with utmost efficiency.', 'pl2.jpg', 'PEL'),


(25, '4', '12', 'Oven', 4000, 'Baking Series dw 2810 c', 'dl1.jpg', 'Dalawance'),
(26, '4', '12', 'Oven', 3000, 'Baking Series dw 259 c', 'dl2.jpg', 'Dalawance'),


(27, '5', '13', 'BAT', 35000, 'Plus 20-k Morgans Edition Hard Ball Bats', 'ca1.jpg', 'CA'),
(28, '5', '13', 'BAT', 30000, 'WHITE DRAGON 7 STAR WHITE EDITION HARD BALL BATS', 'ca2.jpg', 'CA'),


(29, '5', '14', 'BAT', 20000, 'BAT', 'hs1.jpg', 'HS'),
(30, '5', '14', 'SPORTS SHOES', 3200, 'SPORTS SHOES', 'hs2.jpg', 'HS'),



(31, '2', '15', 'Kate Kurta GLW-19-210', 10000, 'White, embroidered cambric kurta with crystal button', 'g1.jpg', 'Gul Ahmed'),
(32, '2', '15', 'BAG', 2000, 'BAG', 'g2.jpg', 'Gul Ahmed'),
(33, '2', '15', 'CLUTCH', 2200, 'CLUTCH', 'g3.jpg', 'Gul Ahmed'),
(34, '2', '15', 'CLUTCH', 1500, 'CLUTCH', 'g4.jpg', 'Gul Ahmed'),
(35, '2', '15', 'Lawn 2 PC Outfit IPS-19-132', 3500, 'Cream color, screen-printed lawn shirt with tassel adornment and screen-printed lawn dupatta', 'g5.jpg', 'Gul Ahmed'),
(36, '2', '15', 'Lawn 2 PC Outfit IPS-19-127', 3500, 'Gray, screen-printed lawn shirt with hand-work, tassel adornment and screen-printed lawn dupatta', 'g6.jpg', 'Gul Ahmed'),

(37, '2', '16', 'Printed Kurta', 2500, 'Printed Kurta', 'k1.jpg', 'Khaadi'),
(38, '2', '16', 'Embroidered Kurta with Dupatta', 4400, 'Embroidered Kurta with Dupatta', 'k2.jpg', 'Khaadi'),
(39, '2', '16', 'Printed Kurta with Pants', 4800, 'Printed Kurta with Pants', 'k3.jpg', 'khaadi'),

(40, '2', '17', 'Acrylic Wool Full Sleeve Long Coat', 4200, 'Beige', 'o1.jpg', 'Oxford'),
(41, '2', '17', 'Acrylic Wool Long Coat', 2900, 'Blue', 'o2.jpg', 'Oxford');










CREATE TABLE `received_payment` (
  `id` int(100) NOT NULL,
  `uid` int(100) NOT NULL,
  `amt` int(100) NOT NULL,
  `tr_id` int(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `user_info`
--

CREATE TABLE `user_info` (
  `user_id` int(10) NOT NULL,
  `first_name` varchar(50) NOT NULL,
  `last_name` varchar(50) NOT NULL,
  `email` varchar(300) NOT NULL,
  `password` varchar(100) NOT NULL,
  `mobile` varchar(10) NOT NULL,
  `address1` varchar(300) NOT NULL,
  `address2` varchar(300) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `user_info`
--


--
-- Indexes for dumped tables
--

--
-- Indexes for table `brands`
--
ALTER TABLE `brands`
  ADD PRIMARY KEY (`brand_id`);

--
-- Indexes for table `cart`
--
ALTER TABLE `cart`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `categories`
--
ALTER TABLE `categories`
  ADD PRIMARY KEY (`cat_id`);

--
-- Indexes for table `customer_order`
--
ALTER TABLE `customer_order`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `products`
--
ALTER TABLE `products`
  ADD PRIMARY KEY (`product_id`);

--
-- Indexes for table `received_payment`
--
ALTER TABLE `received_payment`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `user_info`
--
ALTER TABLE `user_info`
  ADD PRIMARY KEY (`user_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `brands`
--
ALTER TABLE `brands`
  MODIFY `brand_id` int(100) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;
--
-- AUTO_INCREMENT for table `cart`
--
ALTER TABLE `cart`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=87;
--
-- AUTO_INCREMENT for table `categories`
--
ALTER TABLE `categories`
  MODIFY `cat_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;
--
-- AUTO_INCREMENT for table `customer_order`
--
ALTER TABLE `customer_order`
  MODIFY `id` int(100) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=33;
--
-- AUTO_INCREMENT for table `products`
--
ALTER TABLE `products`
  MODIFY `product_id` int(100) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=17;
--
-- AUTO_INCREMENT for table `received_payment`
--
ALTER TABLE `received_payment`
  MODIFY `id` int(100) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `user_info`
--
ALTER TABLE `user_info`
  MODIFY `user_id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
